const PAYMENTS = {
	PAYPAL: {
		name: 'PayPal',
	},
	PAYONEER: {
		name: 'Payoneer',
	},
	SWIFT: {
		name: 'Swift',
	},
};

export default PAYMENTS;
